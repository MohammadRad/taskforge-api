# TaskForge API

TaskForge API is a simple yet comprehensive task management backend built with TypeScript, Express and Prisma. It demonstrates best practices for building a RESTful API including authentication, CRUD operations, rate limiting and PostgreSQL integration via Prisma ORM.

## Features

- **User authentication** using JSON Web Tokens (JWT) with access and refresh tokens.
- **Secure password storage** with bcrypt hashing.
- **Task management**: create, read, update and delete tasks scoped to the authenticated user.
- **Rate limiting** to mitigate abuse.
- **Environment configuration** via `.env` file.
- **Prisma ORM** for database interactions with a PostgreSQL backend.
- Ready-to-run **Docker Compose** setup for development.

## Getting Started

1. **Clone the repository** and install dependencies:

   ```bash
   git clone https://github.com/your-username/taskforge-api.git
   cd taskforge-api
   npm install
   ```

2. **Configure the environment**:

   Copy `.env.example` to `.env` and fill in the values for your PostgreSQL database and JWT secrets.

3. **Set up the database**:

   Ensure you have a running PostgreSQL instance. You can use the provided `docker-compose.yml` to start one quickly:

   ```bash
   docker compose up -d db
   ```

   Then generate and apply Prisma migrations:

   ```bash
   npx prisma migrate dev --name init
   npx prisma generate
   ```

4. **Run the development server**:

   ```bash
   npm run dev
   ```

   The server will start on the port specified in your `.env` file (default is `4000`). You can access the API at `http://localhost:4000`.

## API Endpoints

### Authentication

- `POST /api/auth/register` – Register a new user. Body: `{ email, password }`.
- `POST /api/auth/login` – Log in a user and receive access and refresh tokens. Body: `{ email, password }`.
- `POST /api/auth/refresh` – Refresh your access token. Body: `{ refresh }`.

### Tasks (Protected)

All task routes require an `Authorization: Bearer <token>` header with a valid access token.

- `POST /api/tasks` – Create a new task. Body: `{ title, description?, status? }`.
- `GET /api/tasks` – Retrieve all tasks belonging to the authenticated user.
- `GET /api/tasks/:id` – Retrieve a single task by ID.
- `PUT /api/tasks/:id` – Update a task.
- `DELETE /api/tasks/:id` – Delete a task.

## Development Notes

- This project uses **TypeScript** for type safety.
- **Prisma** ORM is used to interact with the PostgreSQL database. See `prisma/schema.prisma` for the data model.
- JWT secrets and expiration times are configurable via environment variables.
- Basic error handling is implemented. You can extend it with proper validation (e.g. using Zod) and more comprehensive error responses.

## Contributing

Feel free to fork the project and submit pull requests. Whether it's fixing a bug, improving documentation or adding new features, contributions are welcome!

## License

This project is licensed under the MIT License.