import { PrismaClient } from '@prisma/client';

// Create a single PrismaClient instance to be reused across the application.
// This helps with connection pooling and prevents exhausting the database connections.
const prisma = new PrismaClient();

export default prisma;