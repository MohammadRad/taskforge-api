import { Router } from 'express';
import { authenticate } from '../middlewares/authMiddleware';
import {
  createTask,
  getTasks,
  getTask,
  updateTask,
  deleteTask
} from '../controllers/taskController';

const router = Router();

// Apply authentication middleware to all task routes
router.use(authenticate);

/**
 * Create a new task for the authenticated user.
 */
router.post('/', createTask);

/**
 * Retrieve all tasks belonging to the authenticated user.
 */
router.get('/', getTasks);

/**
 * Retrieve a single task by ID (must belong to the authenticated user).
 */
router.get('/:id', getTask);

/**
 * Update an existing task (must belong to the authenticated user).
 */
router.put('/:id', updateTask);

/**
 * Delete a task by ID (must belong to the authenticated user).
 */
router.delete('/:id', deleteTask);

export default router;